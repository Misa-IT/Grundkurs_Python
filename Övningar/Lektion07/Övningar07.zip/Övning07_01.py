# Här försöker vi använda funktionen choice från paketet random men
# något är fel med koden. Rätta till så att den fungerar och vi får ut ett
# slumpvist valt element.

import random

my_list = ["Funktionen", "ska", "välja", "en", "av", "dessa", "strängar", "slumpmässigt"]

print(choice(my_list))
