# Den här övningen består av två filer, ni kan använda den här filen som grund
# för den första om ni vill och den andra ska ni skapa själva.

# Skriv ett program där modulen i denna fil, eller en egenskapad om ni
# föredrar det, importerar den andra och kör en funktion från den andra modulen
# med ett argument.
# Funktionsanropet ska alltså innehålla minst ett argument.

# Filen med funktionen är också en del av uppgiften och funktionens
# funktion är valfri.
# Ett möjligt alternativ är en funktion som hälsar användaren
# med ett namn som anges via ett argument antingen genom att skriva in det
# i anropet, som exemplet längst ned i denna fil, eller så kan man be
# användaren att skriva in namnet. Förslagsvis med funktionen input().


# För extra utmaning kan du importera specifikt den funktion
# som du ska anropa.

# Kom ihåg att namn på moduler som ska importeras inte bör innehålla tecken
# utöver a-z och 0-9.



# Ni kan använda nedanstående rader som start för det ni ska skriva, om ni inte
# vill använda nedanstående rader kan ni ta bort dem.

# Här ska du skriva namnet på din andra fil och eventuellt något mer.
import

# Så här kan det se ut när du kallar på funktionen.
my_example_function("Bob")
